<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
	<p>Votre message a bien été pris en compte et notre équipe n'hésitera pas à y répondre au plus tôt !</p>
	<?php
	    require File::build_path(array('view','contact.php'));
	?>
    </body>
</html>
