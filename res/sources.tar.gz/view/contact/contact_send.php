<div>Votre message a bien été pris en compte et notre équipe n'hésitera pas à y répondre au plus tôt !</div>
<?php
      require File::build_path(array("view","contact", "contact.php"));
?>
