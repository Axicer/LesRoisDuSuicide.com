<p id="error">Combinaison login/mot de passe invalide ou inexistant !</p>
<?php
      require File::build_path(array("view", "login", "login_form.php"));
?>