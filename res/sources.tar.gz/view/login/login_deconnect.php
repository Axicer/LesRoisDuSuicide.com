<p>Vous avez été deconnecté correctement !</p>
<a href="./?page=accueil">Retour a l'accueil</a>