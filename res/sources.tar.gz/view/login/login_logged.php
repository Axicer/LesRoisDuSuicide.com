<p>Vous etes a présent connecté !</p>
<a href="./?page=accueil">Retour a l'accueil</a>