<p id="error">Une erreur est survenu dans l'inscription !</p>
<?php
      require File::build_path(array("view", "login", "login_create.php"));
?>