<p id="success">Le produit a été correctement supprimé !</p>
<?php
	require File::build_path(array("view", "admin", "admin.php"));
?>