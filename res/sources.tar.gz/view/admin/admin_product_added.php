<p id="success">Le produit a été correctement ajouté !</p>
<?php
	require File::build_path(array("view", "admin", "admin.php"));
?>