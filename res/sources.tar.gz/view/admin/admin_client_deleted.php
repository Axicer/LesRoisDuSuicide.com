<p id="success">Le client a été correctement supprimé !</p>
<?php
	require File::build_path(array("view", "admin", "admin.php"));
?>