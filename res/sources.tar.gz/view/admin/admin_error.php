<p id="error">Une erreur est survenue !</p>
<?php
	require File::build_path(array("view", "admin", "admin.php"));
?>