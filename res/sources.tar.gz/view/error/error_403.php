<div>
    <div class='big_text'>403 : Tentative de bidouille détectée !</div>
    	<div>
    		<img class="imgError" src="res/imgs/403.png">
    	</div>
    <a href="./?page=accueil">Page principale</a>
</div>