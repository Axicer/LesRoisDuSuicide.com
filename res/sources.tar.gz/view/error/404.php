<div>
    <div class='big_text'>404 : Page inexistante</div>
    	<div>
    		<img class="404" src="res/imgs/404.png" style="width: 200px;">
    	</div>
    <a href="./?page=accueil">Page principale</a>
</div>