<div>
    <div class='big_text'>404 : Page inexistante</div>
    	<div>
    		<img class="imgError" src="res/imgs/404.png">
    	</div>
    <a href="./?page=accueil">Page principale</a>
</div>