<p id="error">Erreur lors de la requete au serveur !</p>
<?php
    require File::build_path(array("view","produits", "produits_form.php"));
?>