<?php
	echo "search: <p>";
	foreach ($products as $p) {
		echo $p->nom."<br>";
	}
	echo "</p>";
?>