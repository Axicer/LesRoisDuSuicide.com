<?php
	require_once "lib/File.php";
	require File::build_path(array("controller", "router.php"));
?>